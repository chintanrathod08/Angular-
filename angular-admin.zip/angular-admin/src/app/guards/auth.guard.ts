import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const user = this.auth.getUser();
    
    if (!user) {
      this.router.navigate(['/login']);
      return false;
    }

    const expectedRoles = route.data['roles'] as string[];
    if (expectedRoles && !expectedRoles.includes(user.role)) {
      if (user.role === 'admin') this.router.navigate(['/home']);
      else if (user.role === 'employee') this.router.navigate(['/attendance']);
      else if (user.role === 'client') this.router.navigate(['/client-dashboard']);
      else this.router.navigate(['/login']);
      return false;
    }

    return true;
  }
}