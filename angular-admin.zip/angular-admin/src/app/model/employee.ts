export interface Employee{
    id: number;
    firstName: string;
    lastName: string;
    gender: string;
    mobile: number;
    password: string;
    rePassword: string;
    department: string;
    designation: string;
    address: string;
    email: string;
    dob: string;
    education: string;
    joindate: string;
    skills: string;
    experience: string;
    location: string;
    about: string;
    file: string;
}   

